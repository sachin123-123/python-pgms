#!/usr/bin/python3
a="vivek"
b="jangir"
c=" "
n=18
print("my age is",+n)
print(a+c+b)
