#!/usr/bin/python3
for i in range(1,11):#creates an integer in range of 1,11
	print(i*2 ,'\t',i*3,'\t',i*4,'\t',i*5)