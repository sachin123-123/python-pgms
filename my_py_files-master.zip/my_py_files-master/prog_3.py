#!/usr/bin/python3
for i in range(2,21):#create an integer in the range 2 to 21
	if(i%2==0):#if i is even,then proceed
		print(i)
